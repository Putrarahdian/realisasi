    <footer class="footer">
      <div class="container-fluid">
        <div class="footer-in">
          <p class="mb-0">&copy; Diskominfo. </p>
        </div>
      </div>
    </footer>